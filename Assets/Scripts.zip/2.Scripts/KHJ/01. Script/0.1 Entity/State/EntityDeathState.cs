using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EntityDeathState : EntityState
{
    protected override void EnterState()
    {
        _entity.RbCompo.velocity = Vector2.zero;
        _entity.AnimCompo.PlayAnimaton(AnimationType.death);

        if (_entity.gameObject.CompareTag("Player"))
        {
            PlayerController.Instance.enabled = false;
            GameOver();
        }
        _entity.EnemyContol.enabled = false;
        _entity.gameObject.tag = "Untagged";
    }


    private void GameOver() // ���� ���� ���� ����� ���⼭ ȣ�� 
    {
        Destroy(_entity.EnemyContol);
        HGScene1.Instance.GameOver();
    }
}
