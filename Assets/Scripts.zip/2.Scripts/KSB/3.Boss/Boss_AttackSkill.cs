using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss_AttackSkill : MonoBehaviour
{
    public Boss _boss;
    public Minimob _minimob;


    public virtual void Boss_Skill1()
    {
        
    }

    public virtual void Boss_Skill2() 
    {
    }

    public virtual void Boss_Skill3()
    { 

    }

    public virtual void Boss_Skill4()
    {

    }


    public virtual void Minimob_Skill1()
    {

    }

    public virtual void Minimob_Skill2()
    {

    }

    public virtual void Minimob_Skill3()
    {

    }


}
