using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss1_Data : MonoBehaviour
{
    public float Speed;
    public int Hp;
}
