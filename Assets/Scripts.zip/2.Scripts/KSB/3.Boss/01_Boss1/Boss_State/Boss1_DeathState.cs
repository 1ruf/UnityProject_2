using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss1_DeathState : BossState
{
    protected override void EnterState()
    {
    }
}
